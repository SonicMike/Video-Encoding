This folder contains 2 batch files which can be  used to transcode video content into something Mediasite can stream.  



* batch-process-video-cbr.bat - Uses the Constants Rate Factor (CRF) style of H.264 encoding - https://trac.ffmpeg.org/wiki/Encode/H.264#crf
* batch-process-video-2pass.bat - Uses the constrained encoding (VBV / maximum bit rate) as described here - https://trac.ffmpeg.org/wiki/Encode/H.264

FFMPEG can be downloaded at https://ffmpeg.zeranoe.com/builds/ for Windows.