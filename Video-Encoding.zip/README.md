# Video Encoding
###  Information about video encoding and Mediasite

Welcome to my archive about video encoding information and Mediasite.  

This is what is included in this repro:

* FFMPEG batch files

* Handbrake information and profiles